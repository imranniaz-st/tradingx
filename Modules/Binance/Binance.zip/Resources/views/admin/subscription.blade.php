<div class="w-full p-5 mb-5 ts-gray-2 rounded-lg transition-all rescron-card" id="subscription">
    <h3 class="capitalize  font-extrabold "><span class="border-b-2">Binance API Setup</span>
    </h3>




    <div class="w-full">
        <div class="grid grid-cols-1 gap-3 mt-5">
            @if (!$is_subscribed)
                <form action="{{ route('admin.binance.free') }}" class="mt-5 gen-form"
                    enctype="multipart/form-data">
                    @csrf

                    <div class="grid grid-cols-1 gap-5">
                        <div class="relative ">
                            <div
                                class="w-full ts-gray-3 p-2 rounded-lg border border-slate-800 hover:border-slate-600 mb-5">
                                
                                <p>
                                    Binance Plugin costs $30/month to use. You can try for 7 days before purchasing. No credit card required, renew only if you achieved good result from free trial.
                                </p>
                                
                                
                            </div>

                            <ul>
                                <li class="flex items-center justify-start space-x-2">
                                    <span>
                                        <svg class="w-4 h-4 text-green-500" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"></path>
                                          </svg>
                                    </span>
                                    <span>
                                        7 days free trial.
                                    </span>
                                </li>

                                <li class="flex items-center justify-start space-x-2">
                                    <span>
                                        <svg class="w-4 h-4 text-green-500" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"></path>
                                          </svg>
                                    </span>
                                    <span>
                                        No Credit card required.
                                    </span>
                                </li>

                                <li class="flex items-center justify-start space-x-2">
                                    <span>
                                        <svg class="w-4 h-4 text-green-500" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"></path>
                                          </svg>
                                    </span>
                                    <span>
                                        Renew only if you like the result.
                                    </span>
                                </li>

                                <li class="flex items-center justify-start space-x-2">
                                    <span>
                                        <svg class="w-4 h-4 text-green-500" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"></path>
                                          </svg>
                                    </span>
                                    <span>
                                        Learn how it works before paying.
                                    </span>
                                </li>

                                <li class="flex items-center justify-start space-x-2">
                                    <span>
                                        <svg class="w-4 h-4 text-green-500" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"></path>
                                          </svg>
                                    </span>
                                    <span>
                                        Get via  <a class="text-orange-500 underline" href="https://t.me/Rescron_AI_Official" target="_blank" rel="noopener noreferrer">Telegram</a>
                                    </span>
                                </li>
                            </ul>
                        </div>

                    </div>





                    <div class="w-full grid grid-cols-1 gap-5 mt-10 mb-10">
                        <button type="submit" class="bg-purple-500 px-2 py-1 rounded-full transition-all">Start Free Trial </button>
                    </div>

                </form>
            @endif



        </div>


    </div>

</div>



@push('scripts')
@endpush
